import java.util.ArrayList;
import java.util.Random;

import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;

/**
 *  Essa eh a classe de controle do jogo do Trabalho de PPOO(GCC178).
 *  O jogo é baseado no "World of Zuul", um jogo de aventura muito simples, com uma 
 *  pequena interface para o usuário jogar.
 *  Nessa extensão, o usuário caminha por uma casa assombrada, em busca do tesouro
 *  perdido. No caminho, ele pode encontrar objetos que o ajudam, como as dicas
 *  e a chave mestra
 * 
 *  Para jogar esse jogo, crie uma instancia dessa classe e chame o metodo
 *  "jogar".
 * 
 *  Essa classe criaos ambientes e os itens do jogo, cria o analisador e comeca o jogo.
 * Ela também lida com os comandos dado pelo usuário
 * 
 * @author  Alice Rezende Ribeiro, Pedro Antônio de Souza
 * @version 2019.11.28.16.54
 */

public class Jogo 
{
    private int tentativas;
    private Ambiente ambienteAtual;
    public ArrayList <Ambiente> ambientes;
    private ChaveMestra chaveMestra;
    private Dica dica1;
    private Dica dica2;
    private Item tesouro;    
        
    /**
     * Cria o jogo e incializa seu mapa interno, além de seus objetos.
     */
    public Jogo() 
    {
        Random ale = new Random();
        tentativas = ale.nextInt(21)+30;
        ambientes = new ArrayList<>();
        chaveMestra = new ChaveMestra();
        dica1 = new Dica("O tesouro não está no");
        dica2 = new Dica("O tesouro está próximo a");
        tesouro = new Item("tesouro", "Tesouro");
    }
    /**
     * Incia o jogo, criando os ambientes, colocando os itens e instanciando a tela
     * Verifica se existe algum item
     */
    public void iniciar () {
        criarAmbientes();
        espalharItens();
        
        Tela.getInstance().updateTentativas(tentativas);
        imprimirBoasVindas();
        achouItem();
    }

    /**
     * Cria todos os ambientes e liga as saidas deles
     */
    private void criarAmbientes()
    {
        Ambiente salaTV, jardim, escritorio, salaJantar, cozinha, quarto1, quarto2, quarto3,
                quarto4, corredor, banheiro1, banheiro2;
      
        // cria os ambientes
        salaTV = new Ambiente("SalaTV");
        jardim = new Ambiente("Jardim");
        escritorio = new Ambiente("Escritorio");
        salaJantar = new Ambiente("SalaJantar");
        cozinha = new Ambiente("Cozinha");
        quarto1 = new Ambiente("Quarto1");
        quarto2 = new Ambiente("Quarto2");
        quarto3 = new Ambiente("Quarto3");
        quarto4 = new Ambiente("Quarto4");
        corredor = new Ambiente("Corredor");
        banheiro1 = new Ambiente("Banheiro1");
        banheiro2 = new Ambiente("Banheiro2");
        
        ambientes.add(jardim);
        ambientes.add(salaTV);
        ambientes.add(escritorio);
        ambientes.add(salaJantar);
        ambientes.add(cozinha);
        ambientes.add(quarto1);
        ambientes.add(quarto2);
        ambientes.add(quarto3);
        ambientes.add(quarto4);
        ambientes.add(corredor);
        ambientes.add(banheiro1);
        ambientes.add(banheiro2);
        
        // inicializa as saidas dos ambientes
        escritorio.ajustarSaidas(salaTV);
        
        salaTV.ajustarSaidas(escritorio);
        salaTV.ajustarSaidas(salaJantar);
        salaTV.ajustarSaidas(jardim);
        
        jardim.ajustarSaidas(salaTV);
        jardim.ajustarSaidas(cozinha);
        
        salaJantar.ajustarSaidas(salaTV);
        salaJantar.ajustarSaidas(cozinha);
        salaJantar.ajustarSaidas(corredor);
        
        cozinha.ajustarSaidas(salaJantar);
        cozinha.ajustarSaidas(jardim);
        
        quarto1.ajustarSaidas(corredor);
        
        quarto2.ajustarSaidas(corredor);
        
        quarto3.ajustarSaidas(corredor);
        quarto3.ajustarSaidas(banheiro2);
        
        quarto4.ajustarSaidas(corredor);
        
        banheiro1.ajustarSaidas(corredor);
        
        corredor.ajustarSaidas(quarto1);
        corredor.ajustarSaidas(quarto2);
        corredor.ajustarSaidas(quarto3);
        corredor.ajustarSaidas(quarto4);
        corredor.ajustarSaidas(banheiro1);
        corredor.ajustarSaidas(salaJantar);
        
        banheiro2.ajustarSaidas(quarto3);

        ambienteAtual = salaTV;

    }
    /**
     *  Sorteia uma ambiente pro item
     */  
    private Ambiente sorteiaAmbienteSemItem (ArrayList<Ambiente> ambientes) {
        int index;
        do{
            Random r = new Random();
            index = r.nextInt(ambientes.size());
            
        }while(ambientes.get(index).getItem() != null);
        return ambientes.get(index);
    }
    /**
     *  Espalha os iens pelos ambientes.
     * Apaga qualquer arquivo pre-existente
     * Padrao Stategy
     */  
    public void espalharItens () {
        File arquivo = new File("itens.txt");
        arquivo.delete();
        
        Ambiente ambienteTesouro = sorteiaAmbienteSemItem(ambientes);
        ambienteTesouro.setItem(tesouro);  
        escreverArquivo(arquivo, "Tesouro: "+ambienteTesouro.getNome());
        
        Ambiente ambienteSorteado = sorteiaAmbienteSemItem(ambientes);
        ambienteSorteado.setItem(chaveMestra);
        escreverArquivo(arquivo, "Chave Mestra: "+ambienteSorteado.getNome());
        
        ambienteSorteado = sorteiaAmbienteSemItem(ambientes);
        ambienteSorteado.setItem(dica1);
        dica1.setNomeAmbiente(ambienteSorteado);
        escreverArquivo(arquivo, "Dica: "+ dica1.getDescricao());
        
        ambienteSorteado = sorteiaAmbienteSemItem(ambienteTesouro.getPortas());
        ambienteSorteado.setItem(dica2);
        dica2.setNomeAmbiente(ambienteSorteado);
        escreverArquivo(arquivo, "Dica: "+ dica2.getDescricao());
    } 
    /**
     *  Escreve no arquivo binario onde os itens estao
     * @param arquivo o arquivo a ser escrito
     * @param texto a ser escrito
     */        
    public void escreverArquivo(File arquivo, String texto){        
        try(BufferedWriter arq = new BufferedWriter(new FileWriter(arquivo,true))){
            arq.append(texto+"\n");
        }catch(IOException e){
            Tela.getInstance().finalizar("Erro inexperado!");
        }
    }
    /**
     * @return se o usuário ainda tem tentativas
     */
    private boolean temTentativas () {
        return (tentativas > 0);
    }
    
    /**
     *  Rotina principal do jogo. Fica em loop ate terminar o jogo.
     * @param comando o comando dado pelo usuario
     * @return o nome do ambiente atual
     */
    public String jogarTela(Comando comando) {
        processarComando(comando);
        
        if(!temTentativas()){
            Tela.getInstance().finalizar("Suas tentativas acabaram! :(\nVocê perdeu.");
        }
        
        return localizacaoAtual();
    }

    /**
     * Imprime a mensagem de abertura para o jogador.
     */
    private void imprimirBoasVindas()
    {
        Tela.getInstance().println();
        Tela.getInstance().println("Bem-vindx à Casa Assombrada!");
        Tela.getInstance().println("Casa Assombrada é um novo jogo de "
                + "aventura e exploração, seu dever é encontrar o tesouro "
                + "escondido com a ajuda de dicas espalhadas pela casa.");
        Tela.getInstance().println("Fantasmas e espíritos malígnos "
                + "estão na sua cola e caso iram te pegar caso demore demais "
                + "dentro da casa ou chame a atenção explodindo erroneamente em "
                + "busca do tesouro! Tome muito cuidado!!!");
        Tela.getInstance().println("Digite 'ajuda' se voce precisar de ajuda.");
        Tela.getInstance().println();
        
        imprimirLocalizacaoAtual();
    }
    

    /**
     * Dado um comando, processa-o (ou seja, executa-o)
     * @param comando O Comando a ser processado e sua açaõ
     */
    private void processarComando(Comando comando) 
    {
        if(comando.ehDesconhecido()) {
            Tela.getInstance().println("Eu nao entendi o que voce disse...");
        }

        String palavraDeComando = comando.getPalavraDeComando();
        if (palavraDeComando.equals("ajuda")) {
            imprimirAjuda();
        }
        else if(palavraDeComando.equals("explodir")){
            explodir();
        }
        else if (palavraDeComando.equals("ir")) {
            irParaAmbiente(comando);
        }
        else if (palavraDeComando.equals("sair")) {
            Tela.getInstance().sair();
        }
        else if(palavraDeComando.equals("observar")){
            observar();
        }
    }
    /**
     * Decrementa as tentativas e exibe na tela.
     */
    private void decrementaTentativas () {
        tentativas--;
        
        Tela.getInstance().updateTentativas(tentativas);
        Tela.getInstance().println("Você tem " + tentativas + " tentativas");
        
        if (tentativas == 0) {
            Tela.getInstance().finalizar("Suas tentativas terminaram.\nVocê perdeu! :(");
        }
    }
     /**
     * Acao de explodir a momba.
     * Passa a mensagem para a tela final do jogo
     */
    private void explodir() {
        boolean explodir = Tela.getInstance().explodir();
        
        if (explodir) {
            if (ambienteAtual.getItem() == tesouro) {
                Tela.getInstance().finalizar("Parabéns, você encontrou o tesouro!");
            }
            else {
                Tela.getInstance().finalizar("O tesouro não está aqui.\nVocê perdeu! :(");
            }
        }
    }
     /**
     * Printa aonde o jogador esta.
     */
    private void observar(){
        imprimirLocalizacaoAtual();
    }

    /**
     * Printe informacoes de ajuda.
     * Aqui nos imprimimos algo bobo e enigmatico e a lista de 
     * palavras de comando
     */
    private void imprimirAjuda() 
    {
        Tela.getInstance().println("Voce esta perdido. Voce esta sozinho. Voce caminha");
        Tela.getInstance().println("em busca do tesouro.");
        Tela.getInstance().println("");
        Tela.getInstance().println("Suas palavras de comando sao:");
        Tela.getInstance().println("   ir sair ajuda explodir");
    }

    /** 
     * Tenta ir em uma direcao. Se existe uma saida entra no 
     * novo ambiente, caso contrario imprime mensagem de erro.
     */
    private void irParaAmbiente(Comando comando) 
    {
        if(!comando.temSegundaPalavra()) {
            // se nao ha segunda palavra, nao sabemos pra onde ir...
            Tela.getInstance().println("Ir pra onde?");
            return;
        }

        String ambiente = comando.getSegundaPalavra();
        
        //portas de ambiente atual, se tiver
        // Tenta sair do ambiente atual
        Ambiente proxAmbiente = ambienteAtual.buscaSaida(ambiente);
        
        if (proxAmbiente == null) {
            Tela.getInstance().println("Nao ha passagem!");
        }
        else {
            if(!chaveMestra.isEncontrado()){
               if(proxAmbiente.porta()){
                    ambienteAtual = proxAmbiente;
                    imprimirLocalizacaoAtual();
                }else{
                    Tela.getInstance().println("Porta emperrada!\nTente novamente!");
                }
                decrementaTentativas();
            }
            else{
                boolean usarChave = false;
                
                if (chaveMestra.getVida() > 0) {
                    usarChave = Tela.getInstance().usarChave(); 
                    
                    Tela.getInstance().println();
                    Tela.getInstance().println("Há passagem!");
                    Tela.getInstance().println("Você deseja: tentar abrir ou usar a chave mestra?");
                    Tela.getInstance().println("Você tem " + tentativas + " tentativas");
                    Tela.getInstance().println("A chave mestra pode ser usada mais " + chaveMestra.getVida() + " vez(es)");
                    Tela.getInstance().println();
                }             
                
                if (usarChave){
                    ambienteAtual = proxAmbiente;
                    imprimirLocalizacaoAtual();
                    chaveMestra.diminuirVida();
                    Tela.getInstance().updateChaveMestra(chaveMestra.getVida());
                }
                else {
                    if(proxAmbiente.porta()){
                        ambienteAtual = proxAmbiente;
                        imprimirLocalizacaoAtual();
                    }
                    else {
                        Tela.getInstance().println("Porta Emperrada! Tente outra vez!");
                    }
                    decrementaTentativas(); 
                }
            }
            achouItem();
        }        
    }
    
    /** 
     * Verifica se existe um objeto no ambiente atual.
     * Se existe, ele identifica de qual tipo, ele mostra e seta como achado 
     */
    public void achouItem(){
        Item item = ambienteAtual.getItem();
        
        if(item != null && !item.isEncontrado()){ 
            item.setEncontrado();
            
            switch (ambienteAtual.getItem().getTipo()) {
                case "chave mestra":
                    Tela.getInstance().println();
                    Tela.getInstance().println("Você achou a chave mestra!");
                    Tela.getInstance().println("Ela pode ser usada "+ chaveMestra.getVida() + " vezes");
                    Tela.getInstance().println();
                    Tela.getInstance().updateChaveMestra(chaveMestra.getVida());
                    break;
                    
                case "dica":
                    Tela.getInstance().println();
                    Tela.getInstance().println("Sua dica é:");
                    Tela.getInstance().println(item.getDescricao());
                    Tela.getInstance().addDica(item.getDescricao());
                    Tela.getInstance().println();
                    break;
            }
            
        }
    }
    
    /** 
     * Imprime onde o jogador se encontra
     */
    public void imprimirLocalizacaoAtual(){
        Tela.getInstance().println();
        Tela.getInstance().println(localizacaoAtual());
        Tela.getInstance().println();
    }
    /** 
     * @return a String com a localizacao atual e saidas 
     */
    public String localizacaoAtual() {
        String retorno = "Voce está em: " + ambienteAtual.getNome();
        retorno += "\nSaídas: " + ambienteAtual.getSaidas();
        return retorno;
    }
}
