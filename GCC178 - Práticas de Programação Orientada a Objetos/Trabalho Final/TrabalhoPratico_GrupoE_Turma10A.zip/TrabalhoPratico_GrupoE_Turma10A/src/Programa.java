/**
 * Classe Programa - classe principal.
 *
 * Essa classe instancia a tela (e por consequencia o jogo) e a exibe 
 * 
 * @author  Alice Rezende Ribeiro, Mateus Carvalho Gonçalves, Pedro Antônio de Souza,Leticia Alves Ferreira
 * @version 2019.05.12.08.23
 */
public class Programa {
    public static void main(String[] args) {
        Tela telaPrincipal = Tela.getInstance();
        telaPrincipal.exibir();
    }

}
