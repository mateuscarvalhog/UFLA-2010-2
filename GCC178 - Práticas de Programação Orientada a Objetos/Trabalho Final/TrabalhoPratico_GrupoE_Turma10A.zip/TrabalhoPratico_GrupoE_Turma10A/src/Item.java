/**
 *Superclasse que cria o item. Contendo seu tipo, sua descricao e um boolean para
 * checar se ele foi encontrado ou nao
 * @author  Alice Rezende Ribeiro, Pedro Antônio de Souza
 * @version 2019.11.28.14.34
 */

public class Item {
    String tipo;
    String descricao;
    private boolean encontrado;
    /**
    * Cria o item 
    * @param tipo qual é o objeto
    * @param descricao sobre o item
    */
    public Item (String tipo, String descricao) {
        this.tipo = tipo;
        this.descricao = descricao;
        this.encontrado = false;
    }
    /**
    * @return o tipo do item 
    */
    public String getTipo() {
        return tipo;
    }
    /**
    * @return a descricao do item 
    */
    public String getDescricao() {
        return descricao;
    }
    /**
    * Define o item como encontrado
    */
    public void setEncontrado() {
        this.encontrado = true;
    }
    /**
    * @return se o item foi encontardo ou nao
    */
    public boolean isEncontrado() {
        return encontrado;
    }
}
