import java.util.Random;

/**
 * Subclasse que cria a chave mestra.
 * Contendo sua vida
 * @author  Alice Rezende Ribeiro, Pedro Antônio de Souza
 * @version 2019.11.28.14.34
 */

public class ChaveMestra extends Item {
    private int vida;
    
    /**
    * Cria o item e a chave mestra, define sua vida
    */
    public ChaveMestra() {
        super("chave mestra", "Chave Mestra");
        Random r = new Random();
        this.vida = r.nextInt(12)+1;
    }
    /**
    @return a vida da chave
    */
    public int getVida() {
        return vida;
    }
    /**
    * Diminuir a vida da chave
    */
    public void diminuirVida(){
        this.vida--;
    }
}
