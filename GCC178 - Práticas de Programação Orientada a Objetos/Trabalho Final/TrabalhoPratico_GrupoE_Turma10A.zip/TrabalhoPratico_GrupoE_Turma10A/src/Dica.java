/**
 * Cria a dica com qual ambiente ela esta
 * @author  Alice Rezende Ribeiro, Pedro Antônio de Souza
 * @version 2019.11.28.15.15
 */

public class Dica extends Item {
    String nomeAmbiente;
    /**
    * Cria a dica
    * @param descricao a ser definida
    */
    public Dica (String descricao) {
        super("dica", descricao);
    }
    /**
    * Coloca a dica no ambiente
    * @param ambiente qual ambiente ela esta
    */
    public void setNomeAmbiente (Ambiente ambiente) {
        nomeAmbiente = ambiente.getNome();
    }
    /**
    * Sobreecreve o metodo da descricao.
    * @return colocar a descricao da forma da dica
    */
    @Override
    public String getDescricao () {
        return super.getDescricao() + ' ' + nomeAmbiente;
    }
    
}
