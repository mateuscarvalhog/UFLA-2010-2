import java.util.ArrayList;
import java.util.Random;
/**
 * Classe Ambiente - um ambiente em um jogo adventure.
 *
 * Esta classe eh parte do Trabalho de PPOO baseado no 
 * "World of Zuul", um jogo de aventura muito simples, baseado em texto.  
 *
 * Um "Ambiente" representa uma localizacao no cenario do jogo. Ele eh
 * conectado aos outros ambientes atraves de portas. Cada porta
 * guarda uma referencia para o ambiente vizinho, armazenados em um ArrayList
 * 
 * Um ambiente tambem pode ter um item, podendo ser o tesouro, a chave ou alguma dica.
 * Se não tiver o atributo é null 
 * 
 * @author  Alice Rezende Ribeiro, Mateus Carvalho Gonçalves, Pedro Antônio de Souza,Leticia Alves Ferreira
 * @version 2019.05.12.08.23
 */
public class Ambiente 
{
    private String nome;
    private ArrayList <Ambiente> portas;
    private Item item;

    /**
     * Cria um ambiente com a "nome" passado. Inicialmente, ele
     * nao tem saidas e nem algum item. O nome do ambiente, 
     * necessário para futuras pesquisas
     * @param nome A descricao do ambiente.
     */
    public Ambiente(String nome) 
    {
        this.item = null;
        this.nome = nome;
        this.portas = new ArrayList<>();
        
    }
    /**
     * @return o item do Ambiente, se não tem, retorna null
     */
    public Item getItem() {
        return item;
    }
    
    /**
     * @param item A ser adicionado no ambiente
     */
    public void setItem(Item item) {
        this.item = item;
    }

    /**
     * Define as saidas do ambiente. Cada direcao ou leva a um
     * outro ambiente ou eh null (nenhuma saida para la).
     * @param ambiente ambiente que tem porta do atual
     */
    public void ajustarSaidas(Ambiente ambiente) 
    {
        portas.add(ambiente);
    }
    /**
     * @return As portas do ambiente.
     */
    public ArrayList<Ambiente> getPortas() {
        return portas;
    }
        
    /**
     * @return O nome do ambiente.
     */
    public String getNome(){
        return nome;
    }
    /**
     * Função que buca uma saida de acordo com seu nome. 
     * @return o ambiente se tiver um correspondente, ou null se n
     * @param nome o nome do ambiente buscado
     */
    public Ambiente buscaSaida(String nome){
        for(Ambiente a: portas){
            if(a.getNome().equals(nome))
                return a;
        }
        return null;
    }
    
    /**
     * @return Todas as saídas de um ambiente como String
     */
    public String getSaidas(){
        String texto = "";
        for (Ambiente p : portas)
            texto += p.getNome() + " ";
        return texto;
    }
    /**
     * Função que simula uma porta. 
     * @return true se a porta esta aberta, e false se esta emperrada
     */
    public boolean porta(){
        Random n = new Random();
        return n.nextBoolean();
    }
}
