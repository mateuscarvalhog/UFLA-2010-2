import javax.swing.BoxLayout;
import javax.swing.BorderFactory;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.text.DefaultCaret;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Image;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Dimension;


/**
 * Classe Tela - a tela de exição do jogo.
 *
 * Esta classe eh parte do Trabalho de PPOO baseado no 
 * "World of Zuul", um jogo de aventura muito simples, baseado em texto.  
 *
 * Essa classe cria a tela(e consequentemente a rotina do jogo) com todos seus componentes
 * necessários como paineis, labels, textareas e fonts, além dos atributos necessários para 
 * o jogo 
 * 
 * @author  Mateus Carvalho Gonçalves, Pedro Antônio de Souza
 * @version 2019.05.12.08.23
 */
public class Tela {
    private static Tela instanciaTelaPrincipal;
    
    
    private Jogo jogo;
    private Analisador analisador;
    
    private final JFrame janela;
    
    private JPanel painelEsquerdo;
    private JPanel painelCentro;
    private JPanel painelDireito;
    private JPanel painelInferior;
    
    private final JLabel tituloTentativas;
    private JLabel numTentativas;
    private final JLabel tituloChaveMestra;
    private JLabel durabilidadeChave;
    private final JLabel tituloDicas;
    private JTextArea terminal;
    private JTextArea linhaDeComando;
    
    private LineBorder bordaPreta = (LineBorder)BorderFactory.createLineBorder(Color.black, 1);
    
    private Font fontTitulo = new Font("Courier new", Font.BOLD, 12);        
    private Font fontDado = new Font("Courier new", Font.PLAIN, 12);
    private Font fontTerminal = new Font("Courier new", Font.PLAIN, 12);
    
    /**
     * Cria um ambiente a tela e o controlador do jogo.
     * Inicialmente, ele cria alguns componentes e chama montar janela
     * Ele é privado, de acordo com o Padrão de Projeto Singleton, para que não haja
     * mais de uma classe criada
     */
    private Tela() {
        jogo = new Jogo();
        analisador = new Analisador();
        
        janela = new JFrame("Casa Assombrada");
        
        //inicializando paineis
        painelEsquerdo = new JPanel();
        painelCentro = new JPanel();
        painelDireito = new JPanel();
        painelInferior = new JPanel();
        
        //inicializando rótulos
        tituloTentativas = new JLabel("Número de tentativas restantes:");
        numTentativas = new JLabel("0");
        tituloChaveMestra = new JLabel("");
        durabilidadeChave = new JLabel("");
        
        tituloDicas = new JLabel("Dicas encontradas:");
        
        terminal = new JTextArea();
        linhaDeComando = new JTextArea("");
        
        
        
        
        montarJanela();
    }
    
    /**
     * Forma de criar a tela de acordo com Singleton.
     * Se já existe uma tela, ela não é criada
     * @return a tela criada
     */
    public static Tela getInstance(){
        if(instanciaTelaPrincipal == null){
                instanciaTelaPrincipal = new Tela();
        }
        return instanciaTelaPrincipal;
    }
    /**
     * Monta a janela do jogo.
     * Garante que o programa irá terminar quando fechar a janela
     * Define o Layout e seus paineis
     * Chama os métodos para criar os paineis
     */
    private void montarJanela() {
        
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        janela.setLayout(new BorderLayout());
        janela.add(BorderLayout.WEST, painelEsquerdo);
        janela.add(BorderLayout.CENTER, painelCentro);
        janela.add(BorderLayout.EAST, painelDireito);
        janela.add(BorderLayout.SOUTH, painelInferior);
        
        montarPainelEsquerdo();
        montarPainelCentro();
        montarPainelDireito();
        montarPainelInferior();
    }
    /**
     * Monta o painel esquerdo.
     * Definr o Layout do painel e suas caracteristicas visuais e 
     * adiciona seus componentes
     */
    private void montarPainelEsquerdo() {
        painelEsquerdo.setLayout(new BoxLayout(painelEsquerdo, BoxLayout.Y_AXIS));
        
        painelEsquerdo.setPreferredSize(new Dimension(220, 300));
        painelEsquerdo.setBackground(Color.white);
        painelEsquerdo.setBorder(bordaPreta);
        
        estilizarLabel(tituloTentativas, "titulo");
        estilizarLabel(numTentativas, "dado");
        estilizarLabel(tituloChaveMestra, "titulo");
        estilizarLabel(durabilidadeChave, "dado");
        
        painelEsquerdo.add(tituloTentativas);
        painelEsquerdo.add(numTentativas);
        painelEsquerdo.add(tituloChaveMestra);
        painelEsquerdo.add(durabilidadeChave);
    }
     /**
     * Monta o painel do centro.
     * Definr o Layout do painel e suas caracteristicas visuais e 
     * adiciona a imagem
     */
    private void montarPainelCentro () {
        painelCentro.setLayout(new GridLayout(1,1));
        painelCentro.setPreferredSize(new Dimension(570, 300));
        painelCentro.setBackground(Color.white);
        painelCentro.setBorder(bordaPreta);
        
        ImageIcon mapa = new ImageIcon("mapa.png");
        mapa.setImage(mapa.getImage().getScaledInstance(550, 277, Image.SCALE_SMOOTH));
        JLabel imagem = new JLabel(mapa);
        
        painelCentro.add(imagem);
    }
     /**
     * Monta o painel direito.
     * Definr o Layout do painel e suas caracteristicas visuais e 
     * adiciona seus componentes
     */
    private void montarPainelDireito () {
        painelDireito.setLayout(new BoxLayout(painelDireito, BoxLayout.Y_AXIS));
        painelDireito.setPreferredSize(new Dimension(220, 300));  
        painelDireito.setBackground(Color.white);
        painelDireito.setBorder(bordaPreta);
             
        estilizarLabel(tituloDicas, "titulo");
        
        painelDireito.add(tituloDicas);     
    }
    /**
     * Monta o painel inferior.
     * Definr o Layout do painel e suas caracteristicas visuais e 
     * adiciona seus componentes, inclusive a barra de rolagem
     * Além disso, cria os eventos e a resposta do programa
     * ao enter no comando.
     */
    private void montarPainelInferior () {
        painelInferior.setLayout(new BoxLayout(painelInferior, BoxLayout.Y_AXIS));
        painelInferior.setPreferredSize(new Dimension(950, 200));
        painelInferior.setBackground(Color.white);
        painelInferior.setBorder(bordaPreta);
        
        linhaDeComando.setPreferredSize(new Dimension(950, 30));
        linhaDeComando.setBackground(Color.white);
        
        linhaDeComando.addKeyListener(new KeyAdapter(){
            @Override
            public void keyPressed(KeyEvent e){
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
                    String enviado = linhaDeComando.getText().trim();
                    if (enviado.length() > 0) {
                        linhaDeComando.setText("");
                        Tela.this.println("\n> " + enviado);

                        Comando comando = analisador.pegarComando(enviado);
                        jogo.jogarTela(comando);
                    }
                }
            }
        });
        
        terminal.setLayout(new BoxLayout(terminal, BoxLayout.Y_AXIS));
        
        DefaultCaret caret = (DefaultCaret)terminal.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
        
        estilizarTextArea(terminal, "terminal");
        estilizarTextArea(linhaDeComando, "linha de comando");
        
        JScrollPane terminalScroll = new JScrollPane(terminal, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        terminalScroll.setPreferredSize(new Dimension(950, 170));
        
        painelInferior.add(terminalScroll);
        painelInferior.add(linhaDeComando);
        
    }
     /**
     * Define as caracteristicas dos textos.
     * @param label o componente que sera estilizado
     * @param tipo qual string a ser estilizada (em qual lugar ela se encaixa)
     */
    private void estilizarLabel (JLabel label, String tipo) {        
        switch (tipo) {
            case "titulo":
                label.setFont(fontTitulo);
                label.setBackground(Color.pink);
                break;
            
            case "dado":
                label.setBorder(new EmptyBorder(0, 0, 20, 0));
                label.setFont(fontDado);
                break;
                
        }
     }
    /**
     * Define as caracteristicas dos textos nas TextAreas.
     * @param textarea o componente que sera estilizado
     * @param tipo qual string a ser estilizada (em qual lugar ela se encaixa)
     */
    private void estilizarTextArea (JTextArea textarea, String tipo) {        
        switch (tipo) {
            case "dado":
                textarea.setBorder(new EmptyBorder(0, 0, 20, 0));
                textarea.setFont(fontDado);
                break;
            
            case "terminal":
                textarea.setFont(fontTerminal);
                textarea.setLineWrap(true);
                textarea.setWrapStyleWord(true);
                textarea.setBackground(Color.WHITE);
                textarea.setEditable(false);
                break;
            
            case "linha de comando":
                textarea.setFont(fontTerminal);
                textarea.setLineWrap(false);
                textarea.setWrapStyleWord(false);
                textarea.setBackground(Color.WHITE);
                break;
        }
        
        textarea.setForeground(Color.BLACK);
    }
    /**
     * Adiciona a dica em seu painel
     * @param dica qual dica será colocada
     */
    public void addDica (String dica) {
        JLabel labelDica = new JLabel(dica);
        estilizarLabel(labelDica, "dado");
        painelDireito.add(labelDica);
    }
    /**
     * Atualiza o valor da chave mestra
     * @param durabilidade o valor da durabilidade da chave mestra
     */
    public void updateChaveMestra (int durabilidade) {
        if (tituloChaveMestra.getText().equals("")) {
            tituloChaveMestra.setText("Durabilidade da chave mestra:");
        }
        
        durabilidadeChave.setText(Integer.toString(durabilidade));
    }
    /**
     * Atualiza o valor das tentaivas
     * @param tentativas quantas tentativas o jogador ainda tem
     */
    public void updateTentativas (int tentativas) {
        numTentativas.setText(Integer.toString(tentativas));
    }
    /**
     * Funcao para adicionar uma quebra de linha
     * @param linha a linha que a quebra será adicionada apos
     */
    public void println (String linha) {
        terminal.append(linha+"\n");
    }
    /**
     * Funcao para adicionar uma quebra de linha
     */
    public void println () {
        println("");
    }
    /**
     * Funcao para exibir a tela
     */
    public void exibir () {
        jogo.iniciar();
        janela.setVisible(true);
        janela.pack();
    }
     /**
     * Funcao para que exibe as opções para abir a posta.
     * Cria uma caixa de dialogo que exibe o usuario se ele quer
     * usar a chave mestra ou tentar abrir a porta
     * @return true se quer usar a chave mestra e false caso contrario
     */
    public boolean usarChave(){
        String[] opcoes = {"Usar chave mestra", "Tentar abrir normalmente"};
        int resposta = JOptionPane.showOptionDialog(janela, "Deseja usar a chave mestra ou tentar abrir normalmente?", "Chave mestra", JOptionPane.DEFAULT_OPTION,
                        JOptionPane.WARNING_MESSAGE, null, opcoes, opcoes[0]);
        if(resposta == 0){
                return true;
        }
        return false;
    }
    /**
     * Funcao para que o usuario saia do jogo.
     * Cria uma caixa de dialogo que pergunta ao usuaro se ele quer sair,
     * se sim, encerra o jogo
     */
    public void sair() {
        String[] opcoes = {"Sim", "Voltar ao jogo"};
        int resposta = JOptionPane.showOptionDialog(janela, "Deseja realmente sair do jogo?", "Sair", JOptionPane.DEFAULT_OPTION,
                        JOptionPane.WARNING_MESSAGE, null, opcoes, opcoes[0]);
        if(resposta == 0)
            finalizar("Obrigado por jogar esse jogo chato!");
    }
    /**
     * Funcao para garantir que o usário queira explodir.
     * Cria uma caixa de dialogo que exibe o usuario se ele quer
     * explodir nesse comodo ou nao
     * @return true se quer explodirario
     */
    public boolean explodir () {
        String[] opcoes = {"Sim", "Melhor não..."};
        int resposta = JOptionPane.showOptionDialog(janela, "Deseja explodir a bomba aqui?", "Explodir", JOptionPane.DEFAULT_OPTION,
                        JOptionPane.WARNING_MESSAGE, null, opcoes, opcoes[0]);
        if(resposta == 0)
            return true;
        else
            return false;
    }
    /**
     * Funcao para que o usuario saia do jogo.
     * Cria uma caixa de dialogo que que indica o encerramento do jogo
     * @param mensagem se o jogador ganhou ou nao
     */
    public void finalizar(String mensagem){
        println(mensagem);
        JOptionPane.showMessageDialog(janela, mensagem, "Fim de Jogo", JOptionPane.WARNING_MESSAGE);
        System.exit(0);
    }
}
